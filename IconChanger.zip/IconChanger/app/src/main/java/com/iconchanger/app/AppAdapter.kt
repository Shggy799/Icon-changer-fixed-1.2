package com.iconchanger.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppAdapter(
    private val onImportClick: (AppItem) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var items: List<AppItem> = emptyList()

    fun submit(list: List<AppItem>) {
        items = list
        notifyDataSetChanged()
    }

    fun refresh(item: AppItem) {
        val i = items.indexOf(item)
        if (i >= 0) notifyItemChanged(i)
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val appIcon: ImageView = v.findViewById(R.id.appIcon)
        val label: TextView = v.findViewById(R.id.appLabel)
        val pkg: TextView = v.findViewById(R.id.appPackage)
        val tile: FrameLayout = v.findViewById(R.id.importTile)
        val newIcon: ImageView = v.findViewById(R.id.newIcon)
        val arrow: ImageView = v.findViewById(R.id.importArrow)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val item = items[position]
        h.appIcon.setImageDrawable(item.icon)
        h.label.text = item.label
        h.pkg.text = item.packageName

        val uri = item.customUri
        if (uri != null) {
            h.newIcon.setImageURI(uri)
            h.arrow.visibility = View.GONE   // picked: show the new icon
        } else {
            h.newIcon.setImageDrawable(null)
            h.arrow.visibility = View.VISIBLE // not picked: show import arrow
        }
        h.tile.setOnClickListener { onImportClick(item) }
    }
}
