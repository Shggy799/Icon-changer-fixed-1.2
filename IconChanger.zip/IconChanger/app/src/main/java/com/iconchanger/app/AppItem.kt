package com.iconchanger.app

import android.graphics.drawable.Drawable
import android.net.Uri

data class AppItem(
    val label: String,
    val packageName: String,
    val icon: Drawable,
    val isSystem: Boolean,
    var customUri: Uri? = null
)
