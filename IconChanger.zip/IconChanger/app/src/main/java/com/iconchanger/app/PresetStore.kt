package com.iconchanger.app

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File

/** Saves sets of chosen icons inside the app's private storage. */
class PresetStore(context: Context) {

    private val root = File(context.filesDir, "presets").apply { mkdirs() }

    private fun clean(name: String) = name.trim().replace(Regex("[^A-Za-z0-9 _-]"), "_")

    fun list(): List<String> =
        root.listFiles { f -> f.isDirectory }?.map { it.name }?.sortedBy { it.lowercase() }
            ?: emptyList()

    /** Copies every picked image into presets/<name>/<package>.png. Returns count saved. */
    fun save(name: String, picks: Map<String, Uri>, cr: ContentResolver): Int {
        val dir = File(root, clean(name))
        dir.deleteRecursively()
        dir.mkdirs()
        var n = 0
        for ((pkg, uri) in picks) {
            try {
                val bmp = cr.openInputStream(uri).use { BitmapFactory.decodeStream(it) } ?: continue
                File(dir, "$pkg.png").outputStream().use {
                    bmp.compress(Bitmap.CompressFormat.PNG, 100, it)
                }
                n++
            } catch (_: Exception) { }
        }
        return n
    }

    /** package name -> file Uri */
    fun load(name: String): Map<String, Uri> {
        val dir = File(root, name)
        return dir.listFiles { f -> f.extension == "png" }
            ?.associate { it.nameWithoutExtension to Uri.fromFile(it) }
            ?: emptyMap()
    }

    fun delete(name: String) {
        File(root, name).deleteRecursively()
    }
}
