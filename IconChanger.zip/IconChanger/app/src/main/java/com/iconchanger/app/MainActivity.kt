package com.iconchanger.app

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: AppAdapter
    private lateinit var progress: ProgressBar
    private lateinit var presets: PresetStore
    private var allApps: List<AppItem> = emptyList()
    private var launcherPkgs: Set<String> = emptySet()
    private var pendingItem: AppItem? = null
    private var showAll = false

    // Import: open the phone storage and pick a PNG/image
    private val pickImage =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            val item = pendingItem
            if (uri != null && item != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Exception) { }
                item.customUri = uri
                adapter.refresh(item)
            }
            pendingItem = null
        }

    // Export: pick the destination folder, then write <package>.png files
    private val pickFolder =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree: Uri? ->
            if (tree != null) exportTo(tree)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        presets = PresetStore(this)
        progress = findViewById(R.id.progress)
        val recycler = findViewById<RecyclerView>(R.id.recycler)
        adapter = AppAdapter { item ->
            pendingItem = item
            pickImage.launch(arrayOf("image/png", "image/*"))
        }
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        findViewById<CheckBox>(R.id.checkAll).setOnCheckedChangeListener { _, checked ->
            showAll = checked
            applyFilter()
        }

        findViewById<View>(R.id.btnPresets).setOnClickListener { showPresetMenu() }

        findViewById<View>(R.id.btnExport).setOnClickListener {
            if (allApps.none { it.customUri != null }) {
                Toast.makeText(this, "Pick at least one icon first", Toast.LENGTH_SHORT).show()
            } else {
                pickFolder.launch(null)
            }
        }

        loadApps()
    }

    private fun loadApps() {
        progress.visibility = View.VISIBLE
        Thread {
            val pm = packageManager

            // Only apps that have a launcher icon (the ones in your app drawer)
            val launchIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val launchables = if (Build.VERSION.SDK_INT >= 33) {
                pm.queryIntentActivities(launchIntent, PackageManager.ResolveInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION") pm.queryIntentActivities(launchIntent, 0)
            }
            val pkgs = launchables.map { it.activityInfo.packageName }.toSet()

            val infos = if (Build.VERSION.SDK_INT >= 33) {
                pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION") pm.getInstalledApplications(0)
            }
            val list = infos.map {
                AppItem(
                    label = it.loadLabel(pm).toString(),
                    packageName = it.packageName,
                    icon = it.loadIcon(pm),
                    isSystem = (it.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                )
            }.sortedBy { it.label.lowercase() }
            runOnUiThread {
                allApps = list
                launcherPkgs = pkgs
                progress.visibility = View.GONE
                applyFilter()
            }
        }.start()
    }

    private fun applyFilter() {
        adapter.submit(
            if (showAll) allApps else allApps.filter { it.packageName in launcherPkgs }
        )
    }

    // ---------------- Presets ----------------

    private fun showPresetMenu() {
        val names = presets.list()
        val items = arrayOf("+ Save current icons as new preset") + names.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Presets")
            .setItems(items) { _, which ->
                if (which == 0) askPresetName() else presetActions(names[which - 1])
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun askPresetName() {
        val picks = allApps.filter { it.customUri != null }
        if (picks.isEmpty()) {
            Toast.makeText(this, "Pick at least one icon first", Toast.LENGTH_SHORT).show()
            return
        }
        val input = EditText(this).apply { hint = "Preset name (e.g. Neon theme)" }
        AlertDialog.Builder(this)
            .setTitle("Save preset")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) {
                    Toast.makeText(this, "Enter a name", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                progress.visibility = View.VISIBLE
                val map = picks.associate { it.packageName to it.customUri!! }
                Thread {
                    val n = presets.save(name, map, contentResolver)
                    runOnUiThread {
                        progress.visibility = View.GONE
                        Toast.makeText(this, "Saved $n icon(s) in \"$name\"", Toast.LENGTH_LONG).show()
                    }
                }.start()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun presetActions(name: String) {
        AlertDialog.Builder(this)
            .setTitle(name)
            .setItems(arrayOf("Load this preset", "Delete this preset")) { _, which ->
                if (which == 0) {
                    val map = presets.load(name)
                    var applied = 0
                    for (app in allApps) {
                        val uri = map[app.packageName] ?: continue
                        app.customUri = uri
                        applied++
                    }
                    applyFilter()
                    Toast.makeText(
                        this,
                        "Loaded $applied icon(s)" +
                            if (map.size > applied) " (${map.size - applied} app(s) not installed)" else "",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    presets.delete(name)
                    Toast.makeText(this, "Deleted \"$name\"", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Back", null)
            .show()
    }

    // ---------------- Export ----------------

    private fun exportTo(tree: Uri) {
        progress.visibility = View.VISIBLE
        Thread {
            var saved = 0
            var failed = 0
            val dir = DocumentFile.fromTreeUri(this, tree)
            if (dir == null || !dir.canWrite()) {
                runOnUiThread {
                    progress.visibility = View.GONE
                    Toast.makeText(this, "Can't write to that folder", Toast.LENGTH_LONG).show()
                }
                return@Thread
            }
            for (item in allApps) {
                val src = item.customUri ?: continue
                try {
                    val name = item.packageName + ".png"
                    dir.findFile(name)?.delete() // overwrite instead of "name (1).png"
                    val out = dir.createFile("image/png", name) ?: throw Exception("create failed")
                    val bmp = contentResolver.openInputStream(src).use {
                        BitmapFactory.decodeStream(it)
                    } ?: throw Exception("decode failed")
                    contentResolver.openOutputStream(out.uri, "wt").use {
                        bmp.compress(Bitmap.CompressFormat.PNG, 100, it!!)
                    }
                    saved++
                } catch (e: Exception) {
                    failed++
                }
            }
            runOnUiThread {
                progress.visibility = View.GONE
                val msg = "Saved $saved icon(s)" + if (failed > 0) ", $failed failed" else ""
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            }
        }.start()
    }
}
